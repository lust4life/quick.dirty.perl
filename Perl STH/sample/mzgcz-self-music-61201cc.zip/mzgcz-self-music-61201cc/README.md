# self-music #
> *收听网盘中的音乐*

----------

- Web框架：Mojolicious

- 播放器：jPlayer

- Web前端：Bootstrap
